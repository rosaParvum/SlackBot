def poop():
    return("Poop")
